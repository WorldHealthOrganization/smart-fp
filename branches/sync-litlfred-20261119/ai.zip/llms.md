# who.fhir.fp-cds#0.2.0: WHO Family Planning Implementation Guide

## Pages

* [Home](index.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Terminology](terminology.md)
* [Extensions](extensions.md)
* [Conversion to FSH](sushi-conversion.md)
* [Downloads](downloads.md)

## Resources

### CodeSystems

* [Extended Codes CodeSystem codes](CodeSystem-extended-content-codes.md)

### ValueSets

* [Contraception backup method provided values](ValueSet-backupcontraceptivemethod-values.md)
* [Breastfeeding status values](ValueSet-breastfeeding-status-values.md)
* [Cigarettes smoked per day values](ValueSet-cigarettes-smoked-per-day-values.md)
* [Contraception Issues and concerns values](ValueSet-contraception-issues-and-concerns-values.md)
* [How contraceptive method is being provided values](ValueSet-contraceptivedeliverymethod-values.md)
* [Current Medications values](ValueSet-current-medications-values.md)
* [FP Recommended Care values](ValueSet-fp-recommended-care-values.md)
* [IUD Insertion status values](ValueSet-iud-insertion-status-values.md)
* [Medical eligibility - text classification values](ValueSet-medical-eligibility-text-classification-values.md)
* [Current conditions affecting Medical Eligibility values](ValueSet-medicaleligibilityconditions-values.md)
* [Medical eligibility - number classification values](ValueSet-medicaleligibilitynumber-values.md)
* [Observations affecting Medical Eligibility values](ValueSet-medicaleligibilityobservations-values.md)
* [Pregnancy intention values](ValueSet-pregnancy-intention-values.md)
* [Reason for family planning visit values](ValueSet-reason-for-family-planning-visit-values.md)
* [Reason for no method at exit values](ValueSet-reason-for-no-method-at-exit-values.md)

### Resource Profiles

* [WHO-FP CarePlan (Backup Contraceptive Method)](StructureDefinition-who-fp-careplan-backup-contraceptive-method.md)
* [WHO-FP CarePlan (Exit Contraceptive Method)](StructureDefinition-who-fp-careplan-exit-contraceptive-method.md)
* [WHO-FP CarePlan (Recommendation)](StructureDefinition-who-fp-careplan-recommendation.md)
* [WHO-FP CarePlan (Requested Contraceptive Method)](StructureDefinition-who-fp-careplan-requested-contraceptive-method.md)
* [WHO-FP Condition (Medical Eligibility)](StructureDefinition-who-fp-condition-medical-eligibility.md)
* [WHO-FP Consent](StructureDefinition-who-fp-consent.md)
* [WHO-FP Device (Contraceptive Method)](StructureDefinition-who-fp-device-contraceptive-method.md)
* [WHO-FP DeviceUseStatement (Exit Contraceptive Method)](StructureDefinition-who-fp-deviceusestatement-exit-contraceptive-method.md)
* [WHO-FP DeviceUseStatement (Requested Contraceptive Method)](StructureDefinition-who-fp-deviceusestatement-requested-contraceptive-method.md)
* [WHO-FP Encounter (Contraception Issues and Concerns) ](StructureDefinition-who-fp-encounter-contraception-issues-and-concerns.md)
* [WHO-FP Encounter](StructureDefinition-who-fp-encounter.md)
* [WHO-FP HealthcareService](StructureDefinition-who-fp-healthcareservice.md)
* [WHO-FP MedicationStatement (Current Medication)](StructureDefinition-who-fp-medicationstatement-current-medication.md)
* [WHO-FP MedicationStatement (Exit Contraceptive Method)](StructureDefinition-who-fp-medicationstatement-exit-contraceptive-method.md)
* [WHO-FP MedicationStatement (Requested Contraceptive Method)](StructureDefinition-who-fp-medicationstatement-requested-contraceptive-method.md)
* [WHO-FP Observation (Breastfeeding Status)](StructureDefinition-who-fp-observation-breastfeeding-status.md)
* [WHO-FP Observation (Days since Last Normal Menses)](StructureDefinition-who-fp-observation-days-since-last-normal-menses.md)
* [WHO-FP Observation (Intercourse since Last Normal Menses)](StructureDefinition-who-fp-observation-intercourse-since-last-normal-menses.md)
* [WHO-FP Observation (Medical eligibility number)](StructureDefinition-who-fp-observation-medical-eligibility-number.md)
* [WHO-FP Observation (Medical eligibility text)](StructureDefinition-who-fp-observation-medical-eligibility-text.md)
* [WHO-FP Observation (Medical Eligibility)](StructureDefinition-who-fp-observation-medical-eligibility.md)
* [WHO-FP Observation (Missed or Late Menses)](StructureDefinition-who-fp-observation-missed-or-late-menses.md)
* [WHO-FP Observation (Pregnancy Intention)](StructureDefinition-who-fp-observation-pregnancy-intention.md)
* [WHO-FP Observation (Reason for no contraceptive method at exit)](StructureDefinition-who-fp-observation-reason-for-no-contraceptive-method-at-exit.md)
* [WHO-FP Observation (Reason for Stopping Contraception)](StructureDefinition-who-fp-observation-reason-for-stopping-contraception.md)
* [WHO-FP Observation (Smoking Status)](StructureDefinition-who-fp-observation-smoking-status.md)
* [WHO-FP Observation (Test Results)](StructureDefinition-who-fp-observation-test-results.md)
* [WHO-FP Procedure (Exit Contraceptive Method)](StructureDefinition-who-fp-procedure-exit-contraceptive-method.md)
* [WHO-FP Procedure (Requested Contraceptive Method)](StructureDefinition-who-fp-procedure-requested-contraceptive-method.md)
* [WHO-FP Procedure (Service Provided)](StructureDefinition-who-fp-procedure-service-provided.md)

### Extensions

* [How contraceptive method is being provided](StructureDefinition-deliverymethod.md)

### ImplementationGuides

* [WHO Family Planning Implementation Guide](index.md)
