# Home - WHO Family Planning Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/who/fp-cds/ImplementationGuide/who.fhir.fp-cds | *Version*:0.2.0 |
| Draft as of 2026-11-19 | *Computable Name*:FPCDS |

### Introduction

This implementation guide provides guidance that is derived from the following WHO guidelines:

* [Medical Eligibility Criteria for Contraceptive Use. 5th ed](http://www.who.int/reproductivehealth/publications/family_planning/MEC-5/en/)
* [World Health Organization (WHO). Selected Practice Recommendations for Contraceptive Use](http://www.who.int/reproductivehealth/publications/family_planning/SPR-3/en/)
* [Family Planning: A Global Handbook for Providers (2018 update)](https://www.who.int/reproductivehealth/publications/fp-global-handbook/en/)
* [Contraceptive eligibility for women at high risk of HIV](https://apps.who.int/iris/bitstream/handle/10665/326653/9789241550574-eng.pdf?ua=1)
* [Adolescent job aid: a handy desk reference tool for primary level health workers](https://www.who.int/maternal_child_adolescent/documents/9789241599962/en/)
* [WHO recommendations on adolescent sexual and reproductive health and rights](https://www.who.int/reproductivehealth/publications/adolescent-srhr-who-recommendations/en/)

For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).

This guide was converted from its original XML/JSON sources to FSH on 2026-11-10, and some profiles and value sets were corrected along the way. **The [Conversion to FSH](sushi-conversion.md) page lists every change, with the changes in meaning first.**

Implementation content, as well as a complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.

Note that the content of this implementation guide is draft material that has not yet been tested or validated for use in production environments.

